
def lambda_handler(event, context):
    temperature = float(event["temperature"])
    unit = event["unit"].upper()

    if unit == "C":
        result = temperature * 9 / 5 + 32
        output_unit = "F"
    elif unit == "F":
        result = (temperature - 32) * 5 / 9
        output_unit = "C"
    else:
        raise ValueError("Unit must be C or F")

    return {
        "temperature": round(result, 2),
        "unit": output_unit
    }
