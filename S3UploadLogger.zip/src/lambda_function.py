
import json
from urllib.parse import unquote_plus

def lambda_handler(event, context):
    for record in event.get("Records", []):
        bucket = record["s3"]["bucket"]["name"]
        key = unquote_plus(record["s3"]["object"]["key"])

        print(json.dumps({
            "message": "File uploaded to S3",
            "bucket": bucket,
            "file": key
        }))

    return {"statusCode": 200}
